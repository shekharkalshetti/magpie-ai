"""
Decorator for monitoring function execution.

Usage:
    @triton.monitor(project_id="my-project", metadata={"model": "gpt-4"})
    def my_llm_function(prompt):
        return llm.call(prompt)
"""
import functools
import threading
import atexit
from typing import Callable, Dict, Any, Optional, Literal
from datetime import datetime
import uuid
import inspect
import json

from triton.client import get_client
from triton.validation import sanitize_metadata
from triton.context import get_context_metadata, merge_metadata
from triton.pii import PIIMode, PIIDetectionError, get_detector

# Track active logging threads to wait for them on exit
_active_threads = []
_threads_lock = threading.Lock()


def _wait_for_logging_threads():
    """Wait for all active logging threads to complete before exit."""
    try:
        with _threads_lock:
            threads_to_wait = list(_active_threads)

        for thread in threads_to_wait:
            try:
                thread.join(timeout=2.0)  # Wait max 2 seconds per thread
            except:
                pass  # Ignore errors during shutdown
    except:
        pass  # Ignore all errors during interpreter shutdown


# Register cleanup function to run on exit
atexit.register(_wait_for_logging_threads)


def monitor(
    project_id: str,
    metadata: Optional[Dict[str, Any]] = None,
    capture_input: bool = True,
    capture_output: bool = True,
    trace_id: Optional[str] = None,
    pii_mode: Literal["disabled", "block", "redact"] = "disabled",
    llm_url: str = "http://localhost:1234",
    llm_model: str = "qwen2.5-1.5b-instruct"
):
    """
    Decorator for monitoring function execution.

    Captures input, output, timing, and metadata for decorated functions.
    Automatically validates metadata and sends logs to backend asynchronously.
    Optionally detects and handles PII in function inputs.

    Args:
        project_id: Project ID (required)
        metadata: Static metadata to attach to all executions
        capture_input: Whether to capture function inputs (default: True)
        capture_output: Whether to capture function outputs (default: True)
        trace_id: Optional trace ID (generated per execution if not provided)
        pii_mode: PII handling mode - "disabled", "block", or "redact" (default: "disabled")
        llm_url: URL of local LM Studio instance (default: "http://localhost:1234")
        llm_model: LM Studio model for PII detection (default: "qwen2.5-1.5b-instruct")

    PII Modes:
        - disabled: No PII detection (default)
        - block: Block execution if PII is detected, raise PIIDetectionError
        - redact: Redact PII from inputs before execution

    Example:
        @triton.monitor(
            project_id="my-project",
            metadata={"model": "gpt-4", "temperature": 0.7},
            pii_mode="redact"
        )
        def generate_completion(prompt: str) -> str:
            return llm.complete(prompt)

    Note:
        - Currently supports synchronous functions only
        - Fails open - never crashes your application
        - Thread-safe - can be used in multi-threaded environments
        - Metadata is validated client-side before sending
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return _execute_monitored(
                func=func,
                args=args,
                kwargs=kwargs,
                project_id=project_id,
                metadata=metadata,
                capture_input=capture_input,
                capture_output=capture_output,
                trace_id=trace_id,
                pii_mode=pii_mode,
                llm_url=llm_url,
                llm_model=llm_model
            )
        return wrapper

    return decorator


def _execute_monitored(
    func: Callable,
    args: tuple,
    kwargs: dict,
    project_id: str,
    metadata: Optional[Dict[str, Any]],
    capture_input: bool,
    capture_output: bool,
    trace_id: Optional[str],
    pii_mode: str,
    llm_url: str,
    llm_model: str
):
    """
    Execute function with monitoring.

    Thread-safe implementation that:
    1. Detects and handles PII (if enabled)
    2. Captures input arguments
    3. Executes the wrapped function
    4. Captures output
    5. Validates metadata
    6. Sends async log to backend

    Always fails open - never raises exceptions related to monitoring.
    """
    client = get_client()

    # Get context metadata if present
    context_meta = get_context_metadata()

    # Use context project_id if decorator doesn't have one
    effective_project_id = project_id
    if context_meta and context_meta.project_id and not project_id:
        effective_project_id = context_meta.project_id

    # Use context trace_id if decorator doesn't have one
    effective_trace_id = trace_id
    if context_meta and context_meta.trace_id and not trace_id:
        effective_trace_id = context_meta.trace_id

    # Generate trace_id if still None
    execution_trace_id = effective_trace_id or str(uuid.uuid4())

    # Merge metadata: decorator metadata + context metadata
    # Context metadata takes precedence
    exec_metadata = None
    try:
        context_metadata = context_meta.metadata if context_meta else None
        merged_meta = merge_metadata(metadata, context_metadata)
        if merged_meta:
            exec_metadata = sanitize_metadata(merged_meta)
    except Exception:
        # Fail open - continue without metadata
        exec_metadata = None

    # PII Detection and Handling (before input capture)
    pii_info = None
    original_args = args
    original_kwargs = kwargs

    if pii_mode and pii_mode != "disabled":
        try:
            mode = PIIMode(pii_mode)
            detector = get_detector(llm_url=llm_url, model=llm_model)

            # Process positional args
            processed_args = list(args)
            for i, arg in enumerate(args):
                processed_arg, arg_pii_info = detector.process_input(arg, mode)
                processed_args[i] = processed_arg
                if arg_pii_info:
                    pii_info = arg_pii_info

            # Process keyword args
            processed_kwargs = kwargs.copy()
            for key, value in kwargs.items():
                processed_value, kwarg_pii_info = detector.process_input(
                    value, mode)
                processed_kwargs[key] = processed_value
                if kwarg_pii_info:
                    pii_info = kwarg_pii_info

            # Update args/kwargs with processed versions
            args = tuple(processed_args)
            kwargs = processed_kwargs

            # Add PII info to metadata if detection occurred
            if pii_info and exec_metadata is None:
                exec_metadata = {}
            if pii_info:
                exec_metadata["pii_detection"] = pii_info

        except PIIDetectionError:
            # PII detected and mode is BLOCK - re-raise to block execution
            raise
        except Exception as e:
            # Fail open - if PII detection fails, continue with original args
            args = original_args
            kwargs = original_kwargs
            if exec_metadata is None:
                exec_metadata = {}
            exec_metadata["pii_detection_error"] = str(e)

    # Capture input (using potentially redacted args/kwargs)
    input_data = None
    if capture_input:
        try:
            input_data = _capture_input(func, args, kwargs)
        except Exception:
            # Fail open - continue without input capture
            input_data = None

    # Execute function with timing
    started_at = datetime.utcnow()
    error_message = None
    status = "success"
    output_data = None
    result = None

    try:
        # Execute the actual function
        result = func(*args, **kwargs)

        # Capture output
        if capture_output:
            try:
                output_data = _capture_output(result)
            except Exception:
                # Fail open - continue without output capture
                output_data = None

        return result

    except Exception as e:
        # Capture error information
        status = "error"
        error_message = str(e)
        raise  # Re-raise to preserve original behavior

    finally:
        # Always send log, even if function failed
        completed_at = datetime.utcnow()
        duration_ms = int((completed_at - started_at).total_seconds() * 1000)

        # Send log asynchronously in background thread
        # This ensures we don't block the main execution
        try:
            _send_log_async(
                client=client,
                project_id=effective_project_id,
                input_data=input_data,
                output_data=output_data,
                metadata=exec_metadata,
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
                status=status,
                error_message=error_message,
                function_name=func.__name__,
                trace_id=execution_trace_id
            )
        except Exception:
            # Fail open - never crash user's code due to monitoring
            pass


def _capture_input(
    func: Callable,
    args: tuple,
    kwargs: dict
) -> Dict[str, Any]:
    """
    Capture function input arguments.

    Returns a JSON-serializable representation of the input.
    """
    try:
        # Get function signature
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()

        # Create input dictionary with parameter names and values
        input_dict = {}
        for param_name, param_value in bound_args.arguments.items():
            # Try to serialize each parameter
            try:
                # Test JSON serializability
                json.dumps(param_value)
                input_dict[param_name] = param_value
            except (TypeError, ValueError):
                # If not serializable, store type and string representation
                input_dict[param_name] = {
                    "_type": type(param_value).__name__,
                    "_repr": str(param_value)[:100]  # Truncate long strings
                }

        return input_dict

    except Exception:
        # Fallback: just capture basic info
        return {
            "_args_count": len(args),
            "_kwargs_keys": list(kwargs.keys())
        }


def _capture_output(result: Any) -> Dict[str, Any]:
    """
    Capture function output.

    Returns a JSON-serializable representation of the output.
    """
    try:
        # Try to serialize directly
        json.dumps(result)
        return {"value": result}
    except (TypeError, ValueError):
        # If not serializable, store type and string representation
        return {
            "_type": type(result).__name__,
            "_repr": str(result)[:100]  # Truncate long strings
        }


def _send_log_async(
    client,
    project_id: str,
    input_data: Optional[Dict[str, Any]],
    output_data: Optional[Dict[str, Any]],
    metadata: Optional[Dict[str, Any]],
    started_at: datetime,
    completed_at: datetime,
    duration_ms: int,
    status: str,
    error_message: Optional[str],
    function_name: str,
    trace_id: str
):
    """
    Send log to backend asynchronously in a background thread.

    Thread-safe implementation that doesn't block the main execution.
    """
    def send_in_thread():
        try:
            # Use synchronous HTTP request (no asyncio, works during shutdown)
            client.send_log_sync(
                project_id=project_id,
                input=input_data,
                output=output_data,
                metadata=metadata,
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
                status=status,
                error_message=error_message,
                function_name=function_name,
                trace_id=trace_id
            )
        except Exception:
            # Fail open - silently ignore all errors
            pass
        finally:
            # Remove thread from active list when done
            try:
                with _threads_lock:
                    if thread in _active_threads:
                        _active_threads.remove(thread)
            except:
                pass

    # Start background thread (non-daemon so logs complete before exit)
    thread = threading.Thread(target=send_in_thread, daemon=False)

    # Track active thread
    with _threads_lock:
        _active_threads.append(thread)

    thread.start()
