"""
PII Detection and Redaction Module.

Uses local Ollama (gemma3 270m) to detect and optionally redact PII.
Supports three modes: disabled, block, redact.
"""
import json
import requests
from typing import Dict, Any, Optional, Tuple
from enum import Enum


class PIIMode(Enum):
    """PII handling modes."""
    DISABLED = "disabled"
    BLOCK = "block"
    REDACT = "redact"


class PIIDetectionError(Exception):
    """Raised when PII is detected and mode is BLOCK."""
    pass


class PIIDetector:
    """Handles PII detection and redaction using local LM Studio."""

    def __init__(self, llm_url: str = "http://localhost:1234", model: str = "qwen2.5-1.5b-instruct"):
        """
        Initialize PII detector.

        Args:
            llm_url: URL of local LM Studio instance
            model: Model to use for PII detection (default: qwen2.5-1.5b-instruct)
        """
        self.llm_url = llm_url
        self.model = model
        self.api_endpoint = f"{llm_url}/v1/chat/completions"
        self._cache = {}  # Cache for analyzed texts

    def _create_detection_prompt(self, text: str) -> str:
        """Create prompt for PII detection."""
        return f"""Replace ALL personally identifiable information with [REDACTED].

PII types: email addresses, phone numbers, names, SSN, credit cards, addresses, IP addresses, dates of birth, IDs.

Text: {text}

Return JSON in this exact format:
{{"contains_pii": true, "pii_types": ["email", "phone"], "redacted_text": "text with values replaced by [REDACTED]"}}

Example:
Input: "Email: john@test.com, Phone: 555-1234"
Output: {{"contains_pii": true, "pii_types": ["email", "phone"], "redacted_text": "Email: [REDACTED], Phone: [REDACTED]"}}

Now process the text above and return ONLY the JSON:"""

    def detect_and_redact(self, text: str, mode: PIIMode) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
        """
        Detect PII in text and optionally redact.

        Args:
            text: Input text to analyze
            mode: PII handling mode

        Returns:
            Tuple of (contains_pii, redacted_text, detection_info)

        Raises:
            PIIDetectionError: If mode is BLOCK and PII is detected
        """
        if mode == PIIMode.DISABLED:
            return False, None, None

        if not text or not isinstance(text, str):
            return False, None, None

        # Check cache first
        # Cache key with mode and first 100 chars
        cache_key = f"{mode.value}:{text[:100]}"
        if cache_key in self._cache:
            cached = self._cache[cache_key]
            return cached["contains_pii"], cached.get("redacted_text"), cached.get("detection_info")

        try:
            # Call LM Studio API
            prompt = self._create_detection_prompt(text)

            response = requests.post(
                self.api_endpoint,
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0,
                    "max_tokens": 500,
                    "stream": False
                },
            )

            response.raise_for_status()
            result = response.json()

            # Parse response from LM Studio format
            try:
                response_text = result.get("choices", [{}])[0].get(
                    "message", {}).get("content", "{}")

                # Clean up response text - remove markdown code blocks if present
                response_text = response_text.strip()
                if response_text.startswith("```json"):
                    response_text = response_text[7:]  # Remove ```json
                if response_text.startswith("```"):
                    response_text = response_text[3:]  # Remove ```
                if response_text.endswith("```"):
                    response_text = response_text[:-3]  # Remove trailing ```
                response_text = response_text.strip()

                detection_result = json.loads(response_text)
            except json.JSONDecodeError as e:
                # Fallback: no PII detected if parsing fails
                # Log the actual response for debugging
                return False, None, {
                    "error": f"Failed to parse PII detection response: {str(e)}",
                    "raw_response": response_text[:200] if 'response_text' in locals() else "N/A"
                }

            contains_pii = detection_result.get("contains_pii", False)
            pii_types = detection_result.get("pii_types", [])
            redacted_text = detection_result.get("redacted_text", text)

            detection_info = {
                "contains_pii": contains_pii,
                "pii_types": pii_types,
                "mode": mode.value
            }

            # Cache the result
            self._cache[cache_key] = {
                "contains_pii": contains_pii,
                "redacted_text": redacted_text if mode == PIIMode.REDACT else None,
                "detection_info": detection_info
            }

            # Limit cache size to prevent memory issues
            if len(self._cache) > 100:
                # Remove oldest entry
                self._cache.pop(next(iter(self._cache)))

            # Handle based on mode
            if contains_pii and mode == PIIMode.BLOCK:
                raise PIIDetectionError(
                    f"PII detected in input. Types: {', '.join(pii_types)}. "
                    "Operation blocked by PII protection policy."
                )

            if contains_pii and mode == PIIMode.REDACT:
                return True, redacted_text, detection_info

            return contains_pii, None, detection_info

        except requests.exceptions.RequestException as e:
            # Fail open - if LM Studio is not available, don't block execution
            return False, None, {"error": f"LM Studio connection failed: {str(e)}"}
        except PIIDetectionError:
            # Re-raise block errors
            raise
        except Exception as e:
            # Fail open for other errors
            return False, None, {"error": f"PII detection failed: {str(e)}"}

    def process_input(self, input_data: Any, mode: PIIMode) -> Tuple[Any, Optional[Dict[str, Any]]]:
        """
        Process input data for PII detection and redaction.

        Args:
            input_data: Input data (can be dict, list, str, etc.)
            mode: PII handling mode

        Returns:
            Tuple of (processed_input, pii_info)

        Raises:
            PIIDetectionError: If mode is BLOCK and PII is detected
        """
        if mode == PIIMode.DISABLED:
            return input_data, None

        # Convert input to analyzable text
        if isinstance(input_data, str):
            text_to_analyze = input_data
        elif isinstance(input_data, dict):
            # Look for common prompt fields
            text_to_analyze = (
                input_data.get("prompt") or
                input_data.get("message") or
                input_data.get("text") or
                json.dumps(input_data)
            )
        elif isinstance(input_data, (list, tuple)):
            text_to_analyze = " ".join(str(item) for item in input_data)
        else:
            text_to_analyze = str(input_data)

        contains_pii, redacted_text, detection_info = self.detect_and_redact(
            text_to_analyze, mode
        )

        # If PII found and redacted, update input
        if contains_pii and mode == PIIMode.REDACT and redacted_text:
            if isinstance(input_data, str):
                return redacted_text, detection_info
            elif isinstance(input_data, dict):
                # Update the dict with redacted text
                redacted_input = input_data.copy()
                if "prompt" in redacted_input:
                    redacted_input["prompt"] = redacted_text
                elif "message" in redacted_input:
                    redacted_input["message"] = redacted_text
                elif "text" in redacted_input:
                    redacted_input["text"] = redacted_text
                return redacted_input, detection_info

        return input_data, detection_info


# Global detector instance
_detector: Optional[PIIDetector] = None


def get_detector(llm_url: str = "http://localhost:1234", model: str = "qwen2.5-1.5b-instruct") -> PIIDetector:
    """Get global PII detector instance."""
    global _detector
    if _detector is None:
        _detector = PIIDetector(llm_url=llm_url, model=model)
    return _detector
